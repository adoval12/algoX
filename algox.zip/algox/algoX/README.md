# AlgoX

AlgoX is an android app which helps users learn about the stock market. You can play the stock market game manually as well as use algorithms to trade for you. You can also backtest these algorithms to see if they have worked historically. 
